classdef PRCEA < ALGORITHM
% <2026> <multi/many> <real/integer> <large/none> <constrained/none>
% Large-scale evolutionary multi-objective optimization assisted by directed sampling

    methods
        function main(Algorithm,Problem)

            %% Generate random population
            Pop{2}          = Problem.Initialization(); 
            Off             = {[],[]};
            Pop{1}          = Pop{2};

            stage=1;
            lgap         = 20;    % 窗口大小
            change_threshold = 1e-3;  % 停滞阈值
            NP=Problem.N;
            cnt=0;
  
            %% Optimization
            while Algorithm.NotTerminated([Pop{1}])
                cnt=cnt+1;
       
                %% Population Update
                [Pop{1},Fit{1}] = Main_task_EnvironmentalSelection([Pop{1}, Off{1},Off{2}],NP, true);                   
                if stage==1
                    [Pop{2},Fit{2}]   = Auxiliray_task_EnvironmentalSelection([Pop{2}, Off{1},Off{2}],NP,inf);
                else
                    [Pop{2},Fit{2}]   = PRDD(Pop{1},[Pop{2}, Off{1},Off{2}],NP,inf);
                end

               %% Udate ideal point
                for i=1:2
                    zmin{i} = min([Pop{i}.objs], [], 1) - 1e-6;
                    %zmin{i} = min(zmin{i}, min(Offspring.objs, [], 1) - 1e-6);
                end

                %% Update stage,Pop{1}不为空且收敛停滞则stage从1切换至2
                if stage == 1 
                    Objs = Pop{1}.objs;
                    ideal_points(cnt,:) = min(Objs, [], 1);
                    nadir_points(cnt,:) = max(Objs, [], 1);
                    mean_points(cnt,:)  = mean(Objs, 1);
                    if cnt >= lgap
                        max_change = calc_maxchange(ideal_points, nadir_points, mean_points, cnt, lgap);
                        if max_change <= change_threshold
                            stage = 2;
                            switchFE=Problem.FE;
                            X=0;
                        end
                    end
                end
                
                %% Offspring generation
                Off = cell(1, 2);
                for i = 1:2
                    if stage==1
                        Off{i} = Enhanced_DE(Problem, Pop{i}, Fit{i}, zmin{i});
                    else
                        % MatingPool = TournamentSelection(2,NP,Fit{i});
                        % Off{i} = OperatorGAhalf(Problem,Pop{i}(MatingPool));
                        MatingPool = [Pop{i}(randsample(NP,NP))];
                        [Mate1,Mate2,Mate3]  = Neighbor_Pairing_Strategy(MatingPool,zmin{i});
                        Off{i}(1:NP/2) = OperatorDE_rand_1(Problem,Mate1(1:NP/2), Mate2(1:NP/2), Mate3(1:NP/2));
                        Off{i}(1+NP/2:NP) = OperatorDE_pbest_1_main(Problem, Pop{i}, NP/2, Fit{i}, 0.1);
                    end
                end
        
                if Problem.FE>=Problem.maxFE
                    [Pop{1},~] = Main_task_EnvironmentalSelection([Pop{1}, Off{1},Off{2}],Problem.N, true); 
                end
            end
        end
    end
end
